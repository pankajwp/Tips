import QueryEditor from '../../components/common/QueryEditor';

import { render } from '@testing-library/react';

describe('QueryEditor', () => {
  it('should render the QueryEditor component', () => {
    const { container } = render(
      <QueryEditor schemas={['Schema1', 'Schema2']} tables={['Table1', 'Table2']} columns={[]} onClose={() => {}} />,
    );
    expect(container).toBeInTheDocument();
  });
});
