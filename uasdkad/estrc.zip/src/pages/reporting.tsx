import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';

import QueryEditor from '../components/common/QueryEditor';

import QueryResult from '@/components/common/QueryResult';
import ColumnSelectionDataTable, { ColumnData } from '@/components/reportingComponents/ColumnSelectionDataTable';
import ExportPopup from '@/components/reportingComponents/exportPopup';
import ReportingTopbar from '@/components/reportingComponents/reportingTopbar';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/text-area';
import { useToast } from '@/components/ui/use-toast';

function Reporting() {
  // State to store selected values
  const [selectedSchema, setSelectedSchema] = useState<string | null>(null);
  const [selectedLimits, setSelectedLimits] = useState<string | null>(null);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [selectedWhereCondition, setSelectedWhereCondition] = useState<
    string | null
  >(null);
  const [selectedOrderCondition, setSelectedOrderCondition] = useState<
    string | null
  >(null);
  const [selectedOrder, setSelectedOrder] = useState<string>('ASC');
  const [isPreviewOpen, setIsPreviewOpen] = useState<boolean>(false);
  const [columnData, setColumnData] = useState<ColumnData[] | []>([]);
  const [query, setQuery] = useState<string>('');
  const [selectedColumns, setSelectedColumns] = useState<{ [key: string]: boolean }>({});
  const [isQueryEditorOpen, setIsQueryEditorOpen] = useState(false);
  const [queryResult, setQueryResult] = useState<any>(null);
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const application_name = searchParams.get('app_name');
  const archive_id = searchParams.get('archive_id');
  const [databaseName, setDatabaseName] = useState<string>('');

  const { data: schemas } = useQuery({
    queryKey: ['schemas', archive_id],
    queryFn: async () => {
      const res = await fetch('https://o33dd0mr26.execute-api.us-east-1.amazonaws.com/archive/api/get_schemas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archive_id }),
      });
      if (!res.ok) throw new Error('Failed to fetch schemas');
      const data = await res.json();
      setDatabaseName(data.database_name);
      return data.schemas;
    },
  });

  const { data: tables } = useQuery({
    queryKey: ['tables', selectedSchema],
    queryFn: async () => {
      if (!selectedSchema) return [];
      const res = await fetch('https://o33dd0mr26.execute-api.us-east-1.amazonaws.com/archive/api/get_tables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archive_id, schema_name: selectedSchema }),
      });
      if (!res.ok) throw new Error('Failed to fetch tables');
      const data = await res.json();
      return data;
    },
    enabled: !!selectedSchema,
  });

  useEffect(() => {
    // Set selected columns after columnData is set
    setSelectedColumns(
      Object.fromEntries(columnData.map((row) => [row.id, true])),
    );
  }, [columnData]);

  useEffect(() => {
    fetchColumnDetails();
  }, [selectedTable]);

  const handleColumnSelectionChange = (selection: { [key: string]: boolean }) => {
    setSelectedColumns(selection);
  };

  const fetchColumnDetails = async () => {
    const response = await fetch('https://o33dd0mr26.execute-api.us-east-1.amazonaws.com/archive/api/get_columns', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        archive_id: archive_id,
        schema_name: selectedSchema,
        table_name: selectedTable,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to execute query');
    }
    let data = await response.json();
    data = data.map((column, index) => ({
      id: index.toString(),
      column: column,
    }));
    setColumnData(data);
  };

  const buildQuery = () => {
    if (!selectedSchema) {
      toast({
        variant: 'destructive',
        title: 'Schema Missing.',
        description: 'Please select a schema before generating the query.',
      });
      return;
    }
    if (!selectedTable) {
      toast({
        variant: 'destructive',
        title: 'Table Missing.',
        description: 'Please select a table before generating the query.',
      });
      return;
    }
    if (Object.keys(selectedColumns).length === 0) {
      toast({
        variant: 'destructive',
        title: 'Columns Missing.',
        description: 'Please select atleast one column before generating the query.',
      });
      return;
    }
    let selectedColumnNames = '';
    if (columnData.length === Object.keys(selectedColumns).length) {
      selectedColumnNames = '*';
    } else {
      const selectedColumnIds = Object.keys(selectedColumns).filter((key) => selectedColumns[key]);

      selectedColumnNames = columnData
        .filter((col) => selectedColumnIds.includes(col.id))
        .map((col) => col.column)
        .join(', ');
    }

    let generated = `SELECT ${selectedColumnNames} FROM "${selectedTable}"`;
    if (selectedWhereCondition) {
      generated += ` WHERE ${selectedWhereCondition}`;
    }
    if (selectedOrderCondition) {
      generated += ` ORDER BY ${selectedOrderCondition} ${selectedOrder}`;
    }
    if (selectedLimits) {
      generated += ` LIMIT ${selectedLimits}`;
    }
    generated += ';';
    setQuery(generated);
    return generated;
  };

  function previewQuerryClicked() {
    if (buildQuery()) {
      setIsPreviewOpen(true);
    }
  }

  function resetValues() {
    setSelectedSchema(null);
    setSelectedTable(null);
    setSelectedLimits(null);
    setColumnData([...columnData]);
    setSelectedOrderCondition(null);
    setSelectedOrder('ASC');
    setSelectedWhereCondition('');
    setQueryResult(null);
  }

  interface RowData {
    Data: { VarCharValue?: string }[];
  }

  interface InputData {
    Rows: RowData[];
  }

  const handleAthenaTransformation = (data: InputData) => {
    // Extract column names from the first row
    const columns: string[] = data.Rows[0].Data.map((item) => item.VarCharValue || '');

    // Convert rows to list of objects
    const rows: Record<string, string | null>[] = [];
    for (let i = 1; i < data.Rows.length; i++) {
      const rowData: Record<string, string | null> = {};
      for (let j = 0; j < data.Rows[i].Data.length; j++) {
        const key = columns[j];
        const value = data.Rows[i].Data[j].VarCharValue || null;
        rowData[key] = value;
      }
      rows.push(rowData);
    }

    setQueryResult(rows);
  };

  const executeQueryMutation = useMutation({
    mutationFn: async (sqlQuery: string) => {
      const response = await fetch('https://o33dd0mr26.execute-api.us-east-1.amazonaws.com/archive/api/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sql_statement: sqlQuery,
          database_name: databaseName,
        }),
      });
  
      if (!response.ok) {
        throw new Error('Failed to execute query');
      }
  
      const data = await response.json();
      return data.ResultSet;
    },
    onSuccess: (data) => {
      handleAthenaTransformation(data);
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Query Execution Failed',
        description: error.message,
      });
    },
  });

  const handleExecuteQuery = () => {
    const latestQuery = buildQuery();
    if (latestQuery) {
      executeQueryMutation.mutate(latestQuery);
    }
  };
  return (
    <>
      <div className='place-self-center pb-4'>Criteria</div>
      <ReportingTopbar
        schemas={schemas || []}
        tables={tables || []}
        limits={['10', '50', '100']}
        setSelectedSchema={setSelectedSchema}
        setSelectedTable={setSelectedTable}
        setSelectedLimit={setSelectedLimits}
        selectedSchema={selectedSchema}
        selectedTable={selectedTable}
        selectedLimit={selectedLimits}
        databaseName={databaseName}
      />

      <div className='place-self-center pb-4 pt-8'>Data Columns</div>

      <div className='flex flex-row justify-between'>
        <div className='flex flex-col pr-5'>
          <div> Display Columns</div>
          <div>
            <ColumnSelectionDataTable
              columnData={columnData}
              rowSelection={selectedColumns}
              setRowSelection={handleColumnSelectionChange}
            />
          </div>
        </div>
        <div className='flex flex-col'>
          <div className='flex flex-row justify-between'>
            <span className='w-100 mr-40 flex flex-col'>
              <div className='pb-4'>
                {' '}
                Where Clause <em>(Optional)</em>{' '}
              </div>
              <Textarea
                value={selectedWhereCondition || ''}
                onChange={(e) => setSelectedWhereCondition(e.target.value)}
                placeholder="Enter Where Conditional here Ex. Column1 = 'Value'..."
                rows={10}
                cols={70}
              />
            </span>
            <span className='flex flex-col'>
              <div className='pb-4'>
                {' '}
                Order By <em>(Optional)</em>
              </div>
              <Select value={selectedOrderCondition || ''} onValueChange={setSelectedOrderCondition}>
                <SelectTrigger className='w-[240px]'>
                  <SelectValue placeholder='Select Column' />
                </SelectTrigger>
                <SelectContent>
                  {columnData.map((col) => (
                    <SelectItem key={col.id} value={col.column}>
                      {col.column}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className='pb-4 pt-4'>
                {' '}
                Order <em>(Optional)</em>
              </div>
              <Select value={selectedOrder || ''} onValueChange={setSelectedOrder}>
                <SelectTrigger className='w-[240px]'>
                  <SelectValue placeholder='ASC' />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem key={'ASC'} value={'ASC'}>
                    {'ASC'}
                  </SelectItem>
                  <SelectItem key={'DESC'} value={'DESC'}>
                    {'DESC'}
                  </SelectItem>
                </SelectContent>
              </Select>
            </span>
            <div></div>
          </div>
          <div className='self-end'>
            <Button onClick={previewQuerryClicked}> Preview Query </Button>
          </div>
        </div>
      </div>

      <div className='flex flex-row justify-between pt-16'>
        <div>
          <Button onClick={() => setIsQueryEditorOpen(true)}>Open Query Editor</Button>
          {isQueryEditorOpen && (
            <QueryEditor
              schemas={schemas}
              tables={tables}
              columns={columnData}
              onClose={() => setIsQueryEditorOpen(false)}
            />
          )}
        </div>
        <div className='flex w-[300px] justify-between'>
          <Button onClick={handleExecuteQuery}>Execute Query</Button>
          <Button onClick={resetValues}> Reset </Button>
          <Button onClick={() => navigate('/dashboard')}> Back </Button>
        </div>
      </div>
      {queryResult && (
        <div className='mt-6'>
          <QueryResult data={queryResult || []} />
        </div>
      )}

      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className='size-fit'>
          <DialogHeader>
            <DialogTitle>Generated SQL Query</DialogTitle>
          </DialogHeader>
          <span className='break-words rounded-md p-4 text-sm'>{query}</span>
          <DialogFooter>
            <Button onClick={() => setIsPreviewOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <div className='flex justify-end pt-4'>
        {queryResult && (
          <span>
            <ExportPopup queryResult={queryResult} />
            <Button className='ml-4' onClick={() => navigate('/dashboard')}>
              {' '}
              Back{' '}
            </Button>
          </span>
        )}
      </div>
    </>
  );
}

export default Reporting;
