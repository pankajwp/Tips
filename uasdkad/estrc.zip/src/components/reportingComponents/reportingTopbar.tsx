import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface ReportingTopbarProps {
  schemas: any; // Allow any type for columnData
  tables: any; // Allow any type for rowSelection
  limits: any; // Allow any type for rowSelection
  setSelectedSchema: any; // Allow any type for rowSelection
  setSelectedTable: any; // Allow any type for rowSelection
  setSelectedLimit: any; // Allow any type for rowSelection
  selectedSchema: any; // Allow any type for rowSelection
  selectedTable: any; // Allow any type for rowSelection
  selectedLimit: any; // Allow any type for rowSelection
  databaseName: any; // Allow any type for rowSelection
  setRowSelection?: (selection: any) => void; // Allow any type for the selection setter
}

const ReportingTopbar = ({
  schemas,
  tables,
  limits,
  setSelectedSchema,
  setSelectedTable,
  setSelectedLimit,
  selectedSchema,
  selectedTable,
  selectedLimit,
  databaseName,
}: ReportingTopbarProps) => {
  return (
    <>
      <div className='flex flex-row justify-between'>
        <div className='flex flex-col'>
          <div>Database Name</div>
          <div className='pt-3'>{databaseName}</div>
        </div>

        {/* Schema Dropdown */}
        <div className='flex flex-col'>
          <div className='pb-2'>Schema</div>
          <Select value={selectedSchema || ''} onValueChange={setSelectedSchema}>
            <SelectTrigger className='w-[240px]'>
              <SelectValue placeholder='Select Schema' />
            </SelectTrigger>
            <SelectContent>
              {schemas.map((schema) => (
                <SelectItem key={schema} value={schema}>
                  {schema}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Table Dropdown */}
        <div className='flex flex-col'>
          <div className='pb-2'>Table</div>
          <Select value={selectedTable || ''} onValueChange={setSelectedTable}>
            <SelectTrigger className='w-[240px]'>
              <SelectValue placeholder='Select Table' />
            </SelectTrigger>
            <SelectContent>
              {tables.map((tb) => (
                <SelectItem key={tb} value={tb}>
                  {tb}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Limit Dropdown */}
        <div className='flex flex-col'>
          <div className='pb-2'>Limit</div>
          <Select value={selectedLimit || ''} onValueChange={setSelectedLimit}>
            <SelectTrigger className='w-[120px]'>
              <SelectValue placeholder='Select Limit' />
            </SelectTrigger>
            <SelectContent>
              {limits.map((limit) => (
                <SelectItem key={limit} value={limit}>
                  {limit}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </>
  );
};

export default ReportingTopbar;
