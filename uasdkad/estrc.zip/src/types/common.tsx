export type GraphData = {
  displayName: string;
  userPrincipalName: string;
  mail: string;
  businessPhones: string[];
  officeLocation: string;
  jobTitle: string;
};
