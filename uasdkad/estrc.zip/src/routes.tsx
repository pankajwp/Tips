import { createBrowserRouter, Navigate, RouterProvider } from 'react-router-dom';
import { AuthenticatedTemplate, UnauthenticatedTemplate } from '@azure/msal-react';

import App from '@/App';
import Dashboard from '@/pages/Dashboard';
import Login from '@/pages/Login';
import Profile from '@/pages/Profile';
import Reporting from '@/pages/Reporting';
import Unstructured from '@/pages/Unstructured';

const LoginRoute = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    errorElement: <Navigate to='/' replace />,
    children: [
      {
        path: '/',
        element: <Login />,
      },
    ],
  },
]);

/**
 * End User Authorized Routes
 */
const AuthorizedRoutes = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    errorElement: <h2>Error Page</h2>,
    children: [
      {
        path: '/',
        element: <Navigate to='/dashboard' replace />,
      },
      {
        path: '/dashboard',
        element: <Dashboard />,
      },
      {
        path: '/structured-query',
        element: <Reporting />,
      },
      {
        path: '/unstructured',
        element: <Unstructured />,
      },
      {
        path: '/profile',
        element: <Profile />,
      },
    ],
  },
]);

const Router = () => {
  return (
    <>
      <AuthenticatedTemplate>
        <RouterProvider router={AuthorizedRoutes} />;
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <RouterProvider router={LoginRoute} />;
      </UnauthenticatedTemplate>
    </>
  );
};

export default Router;
