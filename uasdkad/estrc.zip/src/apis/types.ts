export type Condition = {
  id: number;
  main: string;
  description: string;
  icon: string;
};
