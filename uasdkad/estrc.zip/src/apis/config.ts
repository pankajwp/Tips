export const API_CONFIG = {
  BASE_URL: '',
  API_KEY: import.meta.env.VITE_APP_API_KEY,
  DEFAULT_PARAMS: {
    appid: import.meta.env.VITE_APP_API_KEY,
  },
};
