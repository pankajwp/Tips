export const ArchivedDataConstant = {
  ID: 'id',
  ARCHIVE_NAME: 'archive_name',
  TIME_SUBMITTED: 'time_submitted',
  LEGAL_HOLD: 'legal_hold',
  DATABASE_ENGINE: 'database_engine',
  GXP: 'gxp',
};

export const WebendpointConstant = {
  URL: 'https://fvlvk0ushh.execute-api.us-east-1.amazonaws.com/',
  ARCHIVE_DATA_LISTING_URL: '',
};
