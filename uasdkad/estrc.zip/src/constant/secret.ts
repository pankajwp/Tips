export default {
  clientId: 'ba95f4e1-831b-426b-9ba1-f36b25bbe1b3',
  tenantId: '7ba64ac2-8a2b-417e-9b8f-fcf8238f2a56',
};
